export class CreateStreamingDto {}
