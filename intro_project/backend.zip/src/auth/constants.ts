// src/auth/constants.ts
export const jwtConstants = {
  secret: 'yourSecretKey', // Replace 'yourSecretKey' with your actual secret key
};
